#ifndef GRUB_MEMORY_CPU_HEADER
#include <grub/efi/memory.h>

//#define GRUB_EFI_MAX_USABLE_ADDRESS 0x980000000fffffffUL
#define GRUB_EFI_MAX_USABLE_ADDRESS 0x98000000ffffffffUL

#endif /* ! GRUB_MEMORY_CPU_HEADER */
